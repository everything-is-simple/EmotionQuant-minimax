# Improvement Plans (Moved)

Canonical location has moved to: `docs/design/enhancements/`

- Main plan: `docs/design/enhancements/eq-improvement-plan-core-frozen.md`
- Enhancement selection analysis: `docs/design/enhancements/enhancement-selection-analysis_claude-opus-max_20260210.md`
- Drafts: `docs/design/enhancements/drafts/`
- 