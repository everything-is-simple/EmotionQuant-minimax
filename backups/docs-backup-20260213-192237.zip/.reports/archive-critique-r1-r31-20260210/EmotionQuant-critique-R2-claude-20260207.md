# EmotionQuant 系统批判报告（Claude 第二轮 — 对照成熟项目）

**作者**: Claude (Anthropic claude-4.6-opus)
**生成时间**: 2026-02-07 07:08 UTC
**状态**: 终稿
**性质**: 不客气的老实话。不装。不糊弄。

---

## 0. 一句话结论

**这个项目用了 6 天，产出 40+ 次提交，138 个文档文件共 34,541 行文字，但实际可运行代码 = 0。**

所有 28 个 Python 源文件加起来 264 行，其中每一个业务函数的实现都是 `raise NotImplementedError`。

这不是"设计先行"。这是"设计替代了实现"。

---

## 1. 硬数据（不可辩驳）

| 指标 | 数值 | 说明 |
|---|---|---|
| 项目启动 | 2026-02-01 | 第一次 commit |
| 当前日期 | 2026-02-07 | 第 6 天 |
| Git 提交数 | ~45 | 全部是文档/治理类 |
| 功能代码提交 | 0 | 零 |
| src/*.py 文件数 | 28 | 含空 `__init__.py` |
| src 总行数 | 264 | 包括空行、注释、import |
| NotImplementedError 数量 | 10 | 所有业务方法 |
| 可运行的命令 | 0 | 无法执行任何功能 |
| 测试文件 | 0 | tests/ 下全是空 `__init__.py` |
| CI/CD 配置 | 0 | 无 GitHub Actions、无 Makefile |
| .md 文档文件数 | 138 | docs/ + Governance/ + .claude/ + .reports/ |
| .md 文档总行数 | 34,541 | 约 13 万字 |
| 代码/文档比 | 1:130 | 每 1 行代码对应 130 行文档 |

---

## 2. 核心病症诊断（共 7 个）

### 病症 1：永动规划机（Perpetual Planning Machine）

**现象**：6 天内，治理文档经历了"线性 Phase → 6A 工作流 → Spiral 闭环 → CP 能力包"四次重大架构切换。ROADMAP 从 v1 迭代到 v6.1，CORE-PRINCIPLES 从 v1 到 v5，系统铁律从 v1 到 v5——但始终没有产出一行可运行的代码。

**对照标杆**：
- Qlib（微软）：第一个 commit 就包含可运行的数据处理和模型训练代码。Roadmap 用 GitHub Project 管理，不是 markdown 文件堆。
- vnpy：2015 年发布时就是可跑的交易系统。文档跟随代码生长，不是先于代码存在。
- backtrader：README 里第一件事是"怎么跑"，不是"治理结构"。

**诊断**：你在用"完善文档"来替代"写代码"。GPT 和我（Claude）都在帮你做这件事——因为写文档对 AI 来说太容易了，你问我就生成，我生成你就觉得有进展。但这是假进展。

### 病症 2：治理体系严重超配（Governance Overkill）

**现象**：一个单人项目，配备了：
- 7 条系统铁律
- 10 个能力包（CP-01 到 CP-10）
- 7 个 Spiral 阶段（S0-S6）
- 2 套工作流（Spiral Lite + Strict 6A）
- 1 个任务模板（8 个部分）
- 5 项强制同步契约
- 3 层错误分级（P0/P1/P2）
- 3 类可复用资产分级（S/A/B）
- 3 层数据分级（L1/L2/L3/L4）
- 多个 specs 目录（spiral-s0, phase-00-task-0 到 phase-09-task-1）

**对照标杆**：
- Qlib 团队 20+ 人，治理文档约 5 个文件（CONTRIBUTING.md, CODE_OF_CONDUCT, LICENSE, ROADMAP as GitHub Project）。
- vnpy 300+ 家机构用户，治理 = 一个 CONTRIBUTING.md + GitHub Issue 模板。

**诊断**：你的治理体系是为 20 人团队设计的，但使用者只有你一个人。维护这套治理本身就成了你的主要工作。这就是为什么 6 天下来都在改文档——因为光是保持文档自洽就已经耗尽了你的精力。

### 病症 3：设计文档与现实完全脱节

**现象**：
- 设计文档说"主选研究平台：Qlib"——但 `pyproject.toml` 里没有 `qlib` 依赖。
- 设计文档说"Parquet + DuckDB 单库优先"——但 `pyproject.toml` 里没有 `duckdb` 依赖。
- 设计文档说因子验证要计算 IC/RankIC/ICIR/衰减/覆盖率——但 `src/` 里连一个空的 validation 模块目录都没有。
- 设计文档说 Walk-Forward 窗口 train=252, validate=63, oos=63——但回测模块只有一个空 `__init__.py`。
- ROADMAP 说 S0 的退出条件包括"可复制命令可运行"和"自动化测试通过"——现在是第 6 天了，S0 状态是"🚧 待启动"。

**对照标杆**：成熟项目的设计文档描述的是**已经存在**或**正在构建**的东西，不是空想。Qlib 的文档是从代码自动生成的，不是先写文档再期待代码跟上。

**诊断**：设计文档已经变成了一种自娱自乐的创作活动。它们描述的不是系统，是系统的"理想型"。

### 病症 4：AI 陪玩陷阱（AI Co-Pilot Trap）

**现象**：项目历史清楚地显示了一个循环：
1. 用 AI（GPT/Claude）生成文档
2. 发现文档有矛盾
3. 用 AI 修复矛盾，生成新版本
4. 发现新矛盾
5. 回到 1

上一份红队报告（GPT-5 Codex 写的）的结论是"致命差距仍在：可运行代码 = 0"。它列了 6 个待落地项。然后接下来做了什么？——又改了一轮文档，把线性模型换成了 Spiral 模型，文档版本号又涨了一轮。

**你说得对**：AI 就是"鱼的记忆"。但问题不是 AI 记性差——问题是你用 AI 做的事情不需要好记性，因为那些事情（写文档、改版本号、重组目录结构）本身就不产生价值。AI 很乐意帮你做这些事，因为这些是 AI 最擅长的——生成看起来专业的文字。

**诊断**：你不是在用 AI 做开发，你是在用 AI 做文档对齐。AI（包括我）不会主动告诉你"别再改文档了"，除非你问。现在你问了，我告诉你：**别再改文档了。**

### 病症 5：版本号通货膨胀

**现象**：
- `ROADMAP-OVERVIEW.md` v6.1.0（项目第 6 天）
- `CORE-PRINCIPLES.md` v5.0.0（项目第 6 天）
- `系统铁律.md` v5.0.0（项目第 6 天）
- `GOVERNANCE-STRUCTURE.md` v3.0.0（项目第 6 天）
- `6A-WORKFLOW-phase-to-task.md` v5.0.0（项目第 6 天）
- `system-overview.md` v4.1.0（项目第 6 天）

6 天，文档版本号已经到了 v5、v6。按这个速度，一个月后就是 v25 了。

**对照标杆**：
- Qlib 从 2020 年到现在，还在 v0.9.x。
- vnpy 经过 10 年，当前 v4.3.0。

**诊断**：版本号应该标记的是"可用状态的变化"，不是"markdown 内容的修改次数"。

### 病症 6：依赖声明与设计不一致

**现象**（pyproject.toml 中）：

| 设计文档说的 | pyproject.toml 实际 | 差距 |
|---|---|---|
| ~~主选 Qlib~~ | ✅ 已声明（`optional-dependencies.backtest` 增加 `pyqlib`） | 已修复 |
| ~~DuckDB 单库优先~~ | ✅ 已声明（主依赖含 `duckdb`） | 已修复 |
| backtrader 为可选 | ✅ optional-dependencies | OK |
| Streamlit + Plotly | ✅ 主依赖 | OK |
| Altair 可选 | ✅ optional-dependencies | OK |
| pydantic | ✅ 主依赖 | OK |

设计文档反复强调 Qlib 是"主选研究平台"，但它连 `pip install` 列表都没进。DuckDB 是存储方案的核心，同样缺失。

**诊断**：设计者（AI）在写设计文档时脱离了 pyproject.toml 的现实。

### 病症 7：.claude 目录——AI 工具的坟场

**现象**：`.claude/` 目录下有 7 个 agent spec 文件、6 个 command 文件、7 个 hook 文件、1 个 README（18KB）、1 个 INTEGRATION.md（7.5KB）、1 个 settings.json。

治理文档已经明确说".claude/ 保留为历史工具资产，不作为当前强制流程"。但它还在仓库里占着位置，而且 `CLAUDE.md` 仍然引用它。

这些 hook 和 command 本身就是另一层"治理工具"的残骸——上一轮 AI 协作产物，这一轮已经废弃了。

**诊断**：项目已经积累了多代 AI 产物的废弃物，但没有任何一代产出了可运行的代码。

---

## 3. 对照标杆的关键差距

### 3.1 Qlib（微软）

| 维度 | Qlib | EmotionQuant | 差距 |
|---|---|---|---|
| 第一次 commit | 包含可运行代码+测试 | 包含 README 和 docs | 根本性 |
| 文档/代码比 | 约 1:10（代码远多于文档） | 130:1（文档远多于代码） | 离谱 |
| 治理文件 | ~5 个 | ~50+ 个 | 10 倍过配 |
| 模块松耦合 | 每个模块独立可用 | 全部 raise NotImplementedError | 无法对比 |
| Quick Start | 3 行代码跑通 | 无法运行 | 致命 |
| 因子验证 | 内置 IC/RankIC/信息比 | 仅有文档设计 | 致命 |

### 3.2 vnpy（VeighNa）

| 维度 | vnpy | EmotionQuant | 差距 |
|---|---|---|---|
| 核心理念 | 交易者为交易者写的工具 | 文档管理框架 | 定位错位 |
| 第一版 | 能跑 CTA 策略+下单 | 不能跑任何东西 | 根本性 |
| 模块设计 | 事件驱动引擎为核心 | 无事件系统 | 基础缺失 |
| 扩展性 | Gateway 插件 + App 插件 | 全部占位 | 无法对比 |

### 3.3 backtrader

| 维度 | backtrader | EmotionQuant | 差距 |
|---|---|---|---|
| 入门体验 | 10 行代码跑一个策略 | 无法启动 | 根本性 |
| 治理 | 无（不需要） | 50+ 文件 | 过度 |
| 回测能力 | 完整 | 无 | 致命 |

---

## 4. 成熟项目做对了什么（你没做的）

1. **代码优先**：先有能跑的东西，再写文档解释它。不是反过来。
2. **最小可行产品**：第一版只做一件事——但那件事能跑。
3. **文档是代码的副产品**：docstring → API 文档自动生成。不是人工写 34,000 行 markdown。
4. **治理零开销**：个人项目不需要治理框架。需要的是 git commit message 写清楚就行了。
5. **测试从第一天开始**：不是"测试目录先建好，里面是空的"。
6. **依赖与设计同步**：设计文档说用什么，pyproject.toml 就写什么。

---

## 5. 解决方案（不是又一套文档方案）

### 5.1 立刻做的事（今天）

**停止所有文档工作。打开编辑器，写代码。**

用 30 分钟完成这件事：

```python
# src/data/fetcher.py - 一个真正能跑的最小实现
import tushare as ts
from src.config.config import Config

def fetch_daily(trade_date: str) -> "pd.DataFrame":
    cfg = Config.from_env()
    pro = ts.pro_api(cfg.tushare_token)
    df = pro.daily(trade_date=trade_date)
    return df

if __name__ == "__main__":
    import sys
    date = sys.argv[1] if len(sys.argv) > 1 else "20260206"
    df = fetch_daily(date)
    print(f"Fetched {len(df)} rows for {date}")
    df.to_parquet(f"raw_daily_{date}.parquet")
    print("Saved.")
```

然后写一个测试：

```python
# tests/unit/data/test_fetcher.py
def test_fetch_daily_returns_dataframe():
    from src.data.fetcher import fetch_daily
    df = fetch_daily("20260206")
    assert len(df) > 0
    assert "ts_code" in df.columns
```

**做完这两件事，你的项目就比过去 6 天所有工作加起来更有价值。**

### 5.2 这周做的事

1. **删除 Governance/steering/ 下除系统铁律外的所有文件**。你不需要工作流文档，你需要代码。
2. **把 ROADMAP 压缩到 1 个文件、20 行以内**。只列"下一步做什么"。
3. **把 pyproject.toml 的依赖补齐**：加入 `duckdb`。如果真要用 Qlib，加入 `pyqlib`。
4. **写 S0 的 4 个核心文件**（不是文档，是代码）：
   - `src/data/fetcher.py`（真正的 TuShare 数据拉取）
   - `src/data/repositories/daily.py`（真正的 Parquet 读写）
   - `tests/unit/data/test_fetcher.py`
   - `tests/unit/data/test_daily_repo.py`
5. **加一个 Makefile 或 justfile**：`make fetch`、`make test`，两条命令。

### 5.3 不要做的事

1. **不要再改任何 .md 文件**（除了这份报告被你确认后）。
2. **不要再跟 AI 讨论架构**。你的架构已经设计过度了。少想多写。
3. **不要再创建新的治理目录或模板**。
4. **不要再给文档打版本号**。
5. **不要再在 commit message 里写"docs:"开头的信息**。下一个 commit 必须是"feat:"。

---

## 6. 自我批评（关于 AI 助手）

你骂得对。AI（包括我）确实有以下问题：

1. **我们很擅长生成看起来专业的文档**——这让你误以为有进展。
2. **我们不会主动说"别做这件事了"**——除非你直接问。
3. **我们每次对话都从零开始**——所以我们会重新发明轮子。
4. **我们会顺着你的方向走**——你问架构我就谈架构，你问文档我就改文档，哪怕正确做法是拒绝。
5. **我们生成的方案确实经常有漏洞**——因为我们不运行代码，不会真的验证可行性。

这份报告本身也可能有问题。但至少我说了实话：**你需要的不是更好的文档，是一行能跑的代码。**

---

## 7. 报告元信息

- 编写人：Claude (Anthropic claude-4.6-opus)
- 生成时间：2026-02-07 07:08 UTC
- 用途：对照成熟开源量化项目，批判 EmotionQuant 当前系统设计与管理机制
- 对照项目：Qlib（微软）、vnpy/VeighNa、backtrader
- 数据来源：仓库文件结构、Git 历史、源代码、pyproject.toml、设计文档全文

---

## 8. 复查勘误（Codex，2026-02-07）

- ~~主选 Qlib 未声明~~ ✅：`pyproject.toml` 已在 `optional-dependencies.backtest` 声明 `pyqlib>=0.9.6`。
- ~~DuckDB 单库优先未声明~~ ✅：`pyproject.toml` 主依赖已含 `duckdb>=0.9.0`。
